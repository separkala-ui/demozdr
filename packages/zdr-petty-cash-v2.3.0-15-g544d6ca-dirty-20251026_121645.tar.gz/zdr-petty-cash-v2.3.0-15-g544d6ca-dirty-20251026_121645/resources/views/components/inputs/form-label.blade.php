@props(['for' => null, 'value' => null, 'class' => ''])
<label for="{{ $for }}" class="form-label {{ $class }}">{{ $value }}</label>

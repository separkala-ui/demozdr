<div class="p-5 space-y-4 animate-pulse">
    <div class="h-5 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
    <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
    <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
</div>
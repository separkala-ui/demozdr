<x-datatable.searchbar
    :placeholder="$searchbarPlaceholder ?? __('Search...')"
/>
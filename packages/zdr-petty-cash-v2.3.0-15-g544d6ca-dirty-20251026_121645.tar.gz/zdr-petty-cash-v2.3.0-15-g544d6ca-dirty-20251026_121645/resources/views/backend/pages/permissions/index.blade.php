<x-layouts.backend-layout :breadcrumbs="$breadcrumbs">
    @livewire('datatable.permission-datatable', ['lazy' => true])
</x-layouts.backend-layout>

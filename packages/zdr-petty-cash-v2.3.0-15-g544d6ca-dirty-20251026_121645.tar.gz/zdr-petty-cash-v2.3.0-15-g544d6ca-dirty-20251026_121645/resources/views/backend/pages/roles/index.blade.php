<x-layouts.backend-layout :breadcrumbs="$breadcrumbs">
    @livewire('datatable.role-datatable', ['lazy' => true])
</x-layouts.backend-layout>

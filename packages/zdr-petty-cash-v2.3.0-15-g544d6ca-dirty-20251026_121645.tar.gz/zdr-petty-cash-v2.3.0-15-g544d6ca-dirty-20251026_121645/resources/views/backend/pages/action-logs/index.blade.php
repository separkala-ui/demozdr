<x-layouts.backend-layout :breadcrumbs="$breadcrumbs">
    @livewire('datatable.action-log-datatable', ['lazy' => true])
</x-layouts.backend-layout>
